<?php 
namespace php\github;

/**
* Class definition @version 1.3.0 @last_update 2020-12-27
*
* Proxy class for calling web services hosted at api.github.com based on GitHub API v3
* Methods with prefix return will call the web services
* Methods with prefix get will return information from the object (cache)
* 
* @Dependencies
*   @lib cURL Client URL Library @see https://www.php.net/manual/en/book.curl.php
*   @class php\github\phpHubResult
*   @array php\github\gh
*   
* @public object methods
*   __construct() @return object @since 1.0.0
*   returnRoot() @return phpHubResult @since 1.0.0 Returns the list of available web services @see phpGithubServiceArray.php 
*   returnRepository(string $owner, string $repo) @return phpHubResult @since 1.0.0  Returns the repository of that owner, caches repository in $repository
*   returnRepositoryCollaborators(string $owner, string $repo) @return phpHubResult @since 1.3.0  Returns the collaborators of a repository
*   returnRepositories(string $owner) @return phpHubResult @since 1.2.0  Returns the repositories of that owner
*   returnRootContent($repo) @return phpHubResult @since 1.0.0 Returns the root content of the repository @see phpGithubContent for parsing content object
*   returnContent($repo, string $path) @return phpHubResult @since 1.0.0 Returns content based on repository and path (getting content from subfolders / subdirectories)
*   returnUserProfile(string $user) @return phpHubUser @since 1.2.0 Returns the GitHub User Profile @see phpGithubUser
*   getRepository() @return repository @since 1.1.0 Returns repository if returnRepository was called first
*   getRootContent() @return rootContent @since 1.1.0 Returns the root content of the repository if returnRootContent was called first
*
* @public object properties
*   $hubhost contains URL of github api host @since 1.0.0
*   $hubgetrepo 
*   $hubgetrepos
*   $hubgetcontent
*   $huboauthauthorize
*   $hubgetuserprofile
*	$hubget_currentuser
*	$hubgetrepos_collaborators
*	$hubputrepos_collaborators
*	$hubgetrepos_invitations
*   $CURLOPT_USERAGENT
*   @type boolean $CURLOPT_RETURNTRANSFER
*/
require_once("phpHubResult.php");
require_once("phpGithubServiceArray.php");

class phpGithub
{
	CONST VERSION = "1.3.0";
	CONST NAME = "phpGithub";
	CONST LAST_UPDATE = "2020-12-27";	
	public $hubhost = "https://api.github.com/"; /* @get @set */
	public $hubgetrepo = "https://api.github.com/repos/{owner}/{repo}";	/* https://api.github.com/repos/openZH/covid_19/contents/fallzahlen_kanton_total_csv */
	public $hubgetrepos = "https://api.github.com/users/{owner}/repos";	/* https://api.github.com/openZH/repos */
	public $hubgetcontent = "https://api.github.com/repos/{repo}/contents/{path}";	/* https://developer.github.com/apps/building-oauth-apps/authorizing-oauth-apps/#redirect-urls */
	public $huboauthauthorize = "https://github.com/login/oauth/authorize?client_id={client_id}&scope={scope}&redirect_uri={redirect_uri}&state={state}";
	public $hubgetuserprofile = "https://api.github.com/users/{user}"; // 1.2.0
	public $hubget_currentuser = "https://api.github.com/user"; // 1.3.0
	public $hubgetrepos_collaborators = "https://api.github.com/repos/{owner}/{repo}/collaborators";	// 1.3.0
	public $hubputrepos_collaborators = "https://api.github.com/repos/{owner}/{repo}/collaborators/{username}"; // 1.3.0
	public $hubgetrepos_invitations = "https://api.github.com/repos/{owner}/{repo}/invitations"; // 1.3.0
	private $contents;		// 1.1.0
	private $hasContents=false; // 1.1.0
	private $repository;		// 1.1.0
	private $hasRepository=false; // 1.1.0
	public $CURLOPT_USERAGENT ="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36";
	public $CURLOPT_RETURNTRANSFER=true;
	private $curl_channel;
	private $curl_open=false;
	private $curl_info;
	private $curl_last_message;
	private $curl_last_err_message;
	private $curl_options=array();
	
	public function __construct() 
	{
		$this->addCurlConfig(CURLOPT_USERAGENT,$this->getPhpUseragent());
		$this->addCurlConfig(CURLOPT_RETURNTRANSFER, true);
	}
	
	function __destruct()
	{
		if($this->curl_open) 
		{
			curl_close($this->getCurlChannel());
		}
	}
	public function getHubhost() 
		{ 
			return $this->hubhost;
		}
		
	public function setHubhost(string $hubhost) 
		{ 
			$this->hobbost=$hubhost;
		}
		
	public function getPhpUseragent() 
		{ 
			return $this->CURLOPT_USERAGENT;
		}
		
	public function setPhpUseragent(string $useragent) 
		{ 
			$this->CURLOPT_USERAGENT=$useragent;
		}
				
	private function setLastCall(array $curl_info)
	{
		$this->curl_info=$curl_info;
	}

	private function getLastCall()
	{
		return $this->curl_info;
	}
	
	private function setLastErrMessage(string $err_message)
	{
		$this->curl_last_err_message=$err_message;
	}
	
	public function getLastErrorMessage()
	{
		return $this->curl_last_err_message;
	}
	
	private function getCurlChannel() 
	{
		if($this->curl_channel == null)
		{
			$this->curl_channel = curl_init();
			$this->curl_open=true;
		} else {
			return $this->curl_channel;
		}
	}
	
	public function addCurlConfig(int $key,string $value)
	{
		$ch=$this->getCurlChannel();
		curl_setopt($this->curl_channel,$key,$value);
		$this->curl_options[$key]=$value;
	}

	// CURLOPT_HTTPHEADER,array ("Accept: application/json")
	public function addCurlHeader(int $key,array $header)
	{
		$ch=$this->getCurlChannel();
		curl_setopt($this->curl_channel,$key,$header);
		$this->curl_options[$key]=$header;
	}	
	
	public function returnRoot()
	{
		$ch=$this->getCurlChannel();
		curl_setopt($ch, CURLOPT_URL, $this->getHubhost());
		$output = curl_exec($ch);
		$err     = curl_errno($ch);
		$errmsg  = curl_error($ch);
		$this->setLastErrMessage("$err $errmsg");
		if($err == 0) 
		{
			$this->setLastCall(curl_getinfo($ch));
			if($this->getLastCall()["http_code"] != 200) 
			{
				$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
				return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,false);
			}
			// if OK
			return new phpHubResult($this->getHubhost(),$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,true);
		} // if Curl NOK
		return new phpHubResult($this->getHubhost(),$err,$errmsg,false,false,$this->curl_options,false);
	}
	
	/* https://api.github.com/repos/{owner}/{repo} */
	public function returnRepository(string $owner,string $repo)
	{
		$url=$this->hubgetrepo;
		$url=str_replace("{owner}",$owner,$url);
		$url=str_replace("{repo}",$repo,$url);
		$ch=$this->getCurlChannel();
		curl_setopt($ch, CURLOPT_URL, $url);
		$output = curl_exec($ch);
		$err     = curl_errno($ch);
		$errmsg  = curl_error($ch);
		$this->setLastErrMessage("$err $errmsg");
		if($err == 0) 
		{
			$this->setLastCall(curl_getinfo($ch));
			if($this->getLastCall()["http_code"] != 200) 
			{
				$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
				return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,false);
			}
			// if ok
			if($this->hasRepository == false)
			{
				$this->repository=json_decode($output);
				$this->hasRepository=true;			
			}
			return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,true);
		}
		return new phpHubResult($url,$err,$errmsg,array(),false,$this->curl_options,false);
	}
	
	/* https://api.github.com/repos/{owner}/{repo}/collaborators */
	public function returnRepositoryCollaborators(string $owner, string $repo)	// 1.1.3
	{
		$url=$this->hubgetrepos_collaborators;
		$url=str_replace("{owner}",$owner,$url);
		$url=str_replace("{repo}",$repo,$url);
		return $this->issueCurlResult($url);
	}
	
/* put https://api.github.com/repos/{owner}/{repo}/collaborators/{username}*/
	public function putRepositoryCollaborator(string $owner, string $repo, string $user) // 1.1.3
	{
		$url=$this->hubputrepos_collaborators;
		$url=str_replace("{owner}",$owner,$url);
		$url=str_replace("{repo}",$repo,$url);
		$url=str_replace("{username}",$user,$url);
		return $this->issueCurlResult($url,"PUT");
	}
	
	/* https://api.github.com/{owner}/repos */	// 1.3.0
	public function returnRepositories(string $owner)
	{
		$url=$this->hubgetrepos;
		$url=str_replace("{owner}",$owner,$url);
		return $this->issueCurlResult($url);
	}
/* https://api.github.com/repos/{owner}/{repo}/invitations*/ // 1.3.0
	public function returnRepositoryInvitations(string $owner, string $repo)
	{
		$url=$this->hubgetrepos_invitations;
		$url=str_replace("{owner}",$owner,$url);
		$url=str_replace("{repo}",$repo,$url);
		return $this->issueCurlResult($url);
	}

/* https://api.github.com/user - requires authentication */ // 1.3.0
	public function returnCurrentUser()
	{
		$url=$this->hubget_currentuser;
		return $this->issueCurlResult($url);
	}
	

	public function issueCurlResult(string $url, string $method='GET') // 1.3.0
	{
		$ch=$this->getCurlChannel();
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
		curl_setopt($ch, CURLOPT_URL, $url);
		$output = curl_exec($ch);
		$err     = curl_errno($ch);
		$errmsg  = curl_error($ch);
		$this->setLastErrMessage("$err $errmsg");
		if($err >=1) // problem with curl e.g. path to TLS Certificates missing
		{
			// construct(string $url,$err,string $errmsg,array $info,$response,array $request,bool $success) 
			return new phpHubResult($url,$err,$errmsg,curl_getinfo($ch),false,$this->curl_options,false);
		}		
		if($err == 0) 
		{
			$this->setLastCall(curl_getinfo($ch));
			if($this->getLastCall()["http_code"] != 200) 
			{
				if($this->getLastCall()["http_code"] == 201) // not an error
				{ 
					return new phpHubResult($url,201,"Created",$this->getLastCall(),json_decode($output),$this->curl_options,true); 
				}
				if($this->getLastCall()["http_code"] == 401) 
				{ 
					$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
					return new phpHubResult($url,401,"Unauthorized",$this->getLastCall(),json_decode($output),$this->curl_options,false); 
				}

				$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
				return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,false);

			}
			// if ok
			return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,true);
		}
	}
		
	public function getRepository()
	{
		return $this->repository;
	}
	/**
	* input = repository object from returnRepository->response
	*
	*/
	public function returnRootContent($repo)
	{
		if(gettype($repo=="object")) 
		{ 
			$repo=$repo->contents_url; 
			$repo=str_replace("{+path}","",$repo);
		}
		$url=$repo;
		$ch=$this->getCurlChannel();
		curl_setopt($ch, CURLOPT_URL, $url);
		$output = curl_exec($ch);
		$err     = curl_errno($ch);
		$errmsg  = curl_error($ch);
		$this->setLastErrMessage("$err $errmsg");
		if($err == 0) 
		{
			$this->setLastCall(curl_getinfo($ch));
			if($this->getLastCall()["http_code"] != 200) 
			{
				$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
				return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,false);
			}		
			if($this->hasContents==false)
			{
				$this->contents=json_decode($output);
				$this->hasContents=true;
			}
			return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,true);
		}
		return new phpHubResult($url,$err,$errmsg,false,false,$this->curl_options,false);
	}
	
	public function getRootContent()
	{
		return $this->contents;
	}
	
	public function returnContent($repo,string $path)
	{
		$url=null;
		if(gettype($repo) == "object") 
		{ 
			$content=$repo->contents_url; 
			$content=str_replace("{+path}",$path,$content);
			$url=$content;
		}
		if(gettype($repo) == "string")
		{
				$url=$this->hubgetcontent;
				$url=str_replace("{repo}",$repo,$url);
				$url=str_replace("{path}",$path,$url);
		}
		if($url == null) { $errmsg="Parameters repo and path did not lead to an URL";$url="no URL";$err=404; return new phpHubResult($url,$err,$errmsg,false,false,$this->curl_options,false);}
		$ch=$this->getCurlChannel();
		curl_setopt($ch, CURLOPT_URL, $url);
		$output = curl_exec($ch);
		$err     = curl_errno($ch);
		$errmsg  = curl_error($ch);
		$this->setLastErrMessage("$err $errmsg");
		if($err == 0) 
		{
			$this->setLastCall(curl_getinfo($ch));
			if($this->getLastCall()["http_code"] != 200) 
			{
				$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
				return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,false);
			}		
			
			return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,true);
		}
		return new phpHubResult($url,$err,$errmsg,false,false,$this->curl_options,false);
	}
	
	public function hasContentsFolder($contents = null) 
	{
		if($contents == null && $this->hasContents) 
		{ 
			$contents=$this->rootContents;
		}
		if(gettype($contents) == "array") {
			foreach($contents as $content)
			{
				if($content->type =="dir") { return true;}
			}
		}
		return false;
	}
	
	public function getContentsIterator($contents = null) 
	{
		if($contents == null && $this->hasContents) 
		{ 
			$contents=$this->contents;
		}
		if(gettype($contents) == "array") {
			return new \ArrayIterator($contents);
		}
	}
	
	/* https://github.com/settings/apps  -> OAuth Apps -> Create New
	   public $huboauthauthorize ="https://github.com/login/oauth/authorize?client_id={client_id}&redirect_uri={redirect_uri}&state={state}";
		Sample redirect_url = http://localhost:1080/webs/githubcallback.php/  
		access_token=9a439ff6d9ad91b9839265ee30ebb60830f7fe7c&scope=&token_type=bearer" 
	*/
	public function requestAccessToken($client_id,$scope,$redirect_uri,$state=true)
	{
		if($state) { $state=bin2hex(openssl_random_pseudo_bytes(32));}
		$url=$this->huboauthauthorize;
		$url=str_replace("{client_id}",$client_id,$url);
		$url=str_replace("{scope}",$scope,$url);
		$url=str_replace("{redirect_uri}",$redirect_uri,$url);
		$url=str_replace("{state}",$state,$url);
		header("Location: $url");
	}

	public function convertCodeToToken($client_id,$client_secret,$code,$state,$redirect_uri)
	{
		$ch=$this->getCurlChannel();
		$url="https://github.com/login/oauth/access_token";
		curl_setopt($ch, CURLOPT_URL, $url);
		$postFields["client_id"]=$client_id;
		$postFields["client_secret"]=$client_secret;
		$postFields["code"]=$code;
		$postFields["redirect_uri"]=$redirect_uri;
		$postFields["state"]=$state;
		curl_setopt($ch,CURLOPT_POSTFIELDS, $postFields);
		$output = curl_exec($ch);
		$err     = curl_errno($ch);
		$errmsg  = curl_error($ch);
		$this->setLastErrMessage("$err $errmsg");
		if($err == 0) 
		{
			$this->setLastCall(curl_getinfo($ch));
			if($this->getLastCall()["http_code"] != 200) 
			{
				$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
				return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,false);
			}
			return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),$output,$this->curl_options,true);
		}
		return new phpHubResult($url,$err,$errmsg,false,false,$this->curl_options,false);

	}
	
	/* lhttps://api.github.com/users/{user} */
	public function returnUserProfile($user)
	{
		$url=$this->hubgetuserprofile;
		$url=str_replace("{user}",$user,$url);
		$ch=$this->getCurlChannel();
		curl_setopt($ch, CURLOPT_URL, $url);
		$output = curl_exec($ch);
		$err     = curl_errno($ch);
		$errmsg  = curl_error($ch);
		$this->setLastErrMessage("$err $errmsg");
		if($err == 0) 
		{
			$this->setLastCall(curl_getinfo($ch));
			if($this->getLastCall()["http_code"] != 200) 
			{
				$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
				return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,false);
			}
			return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,true);
		}
		return new phpHubResult($url,$err,$errmsg,array(),false,$this->curl_options,false);
	}
	
	/* string $url,$err,string $errmsg,array $info,$response,array $request,bool $success */
	public function callWebService($service)
	{

		global $gh;
		if(array_key_exists($service,$gh))
		{
		$url=$gh[$service];
		$ch=$this->getCurlChannel();
		curl_setopt($ch, CURLOPT_URL, $url);
		$output = curl_exec($ch);
		$err     = curl_errno($ch);
		$errmsg  = curl_error($ch);
		$this->setLastErrMessage("$err $errmsg");
		if($err == 0) 
		{
			$this->setLastCall(curl_getinfo($ch));
			if($this->getLastCall()["http_code"] == 404) 
			{ 
				$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
				return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,false); 
			}
			if($this->getLastCall()["http_code"] == 401) 
			{ 
				$this->setLastErrMessage($this->getLastCall()["http_code"]." ".json_decode($output)->message);
				return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),json_decode($output),$this->curl_options,false); 
			}
			if(strpos($this->getLastCall()["content_type"],'json') !==false) { $output=json_decode($output);}
			return new phpHubResult($url,$err,$errmsg,$this->getLastCall(),$output,$this->curl_options,true);
		}
		return new phpHubResult($url,$err,$errmsg,false,false,$this->curl_options,false);
		}
		else
		{
			return new phpHubResult($service,404,"404 $service not found in web service catalog",[],false,$this->curl_options,false);
		}
	}
}

?>
