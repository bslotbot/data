<?php namespace php\github;

/**
* Class definition @version 1.1.1 @last_update 2020-12-15
*
* contains the result of a curl round trip @see phpGithub
* 
* @public object methods
*  __construct(string $url, $err,string $errmsg,array $info, $response,array $request,bool $success) @return object @since 1.0.0
*  __toString() @return string @since 1.0.0
*  hasError() @return boolean @since 1.1.0
*  getErrorCode() @return mixed @since 1.1.0
*  getErrorMessage() @return string @since 1.1.0
*  getErrorHelp($code) @return string @since 1.1.0
*
* @public object properties
*  $info @see curl_getinfo @since 1.0.0
*  $response @see curl_exec json object from github api if curl call was successful @since 1.0.0
*  @type boolean $hasError @since 1.1.0
*
*/
class phpHubResult
{	
	CONST VERSION = "1.1.0";
	CONST NAME = "phpHubResult";
	CONST LAST_UPDATE = "2020-04-09";
	public $url;
	public $err;
	public $errmsg;
	public $info;
	public $response;
	public $request;
	public $success;
	public $failed;
	public $http_code;
	public $content_type;
	public $content_length;
	public $urlip;
	public $hasError=false;
	
	/**
	* Constructor
	* 
	* Creates a new phpHubResult object
	*
	* @see class phpGithub
	* @param string $url result from that url
	* @param mixed $err error code from @see curl_errno
	* @param string $errmsg error message from @see curl_error
	* @param array $info info from @see curl_getinfo
	* @param mixed $response json dedcoded response from @see curl_exec
	* @param array $request curl_options from @see phpGithub
	* @param boolean $success indicator if result is OK or NOK @see phpGithub
	*/
	public function __construct(string $url,$err,string $errmsg,array $info,$response,array $request,bool $success) 
	{
		$this->url=$url;
		$this->err=$err;
		$this->errmsg=$errmsg;
		$this->info=$info;
		$this->response=$response;
		$this->request=$request;
		$this->success=$success;
		$this->failed=! $success;
		$this->initInfo();
	}
	
	private function initInfo() 
	{
		if(isset($this->info["http_code"])) { $this->http_code=$this->info["http_code"];}
		if(isset($this->info["content_type"])) { $this->content_type=$this->info["content_type"];}
		if(isset($this->info["download_content_length"])) { $this->content_length=$this->info["download_content_length"];}
		if(isset($this->info["primary_ip"])) { $this->urlip=$this->info["primary_ip"];}
		if(count($this->info) == 0) {
			$this->response="$this->err $this->errmsg";
			$this->hasError=true;
		}
	}
	
	public function hasError()
	{
		return $this->hasError;
	}
	
	public function getErrorCode()
	{
		return $this->err;
	}
	
	public function getErrorMessage()
	{
		return $this->errmsg;
	}
	
	public function getErrorHelp($code)
	{
		if($code == 6) { return "Check your network, is LAN / WLAN on; DNS Server available";}
		if($code == 60) { return "Curl requires your SSL/TLS Certificate";} // @since 1.1.1
	}
	
	public function __toString()
	{
		if(gettype($this->response) == "object") { return json_encode($this->response);	}
		if(gettype($this->response) == "string") { return $this->response;}
		if(gettype($this->response) == "array") { $o=new \Stdclass();$o->array=$this->response; return json_encode($o); }
		/*echo gettype($this->response)."<br>";*/
		return "";		// @since 1.1.1
	}
}
?>
