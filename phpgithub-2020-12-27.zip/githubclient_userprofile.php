<?php
namespace php\github {
use php\github as hub;
use net\micro_work\php\html as html;
require_once("local.inc"); /* LOCAL_HOST_NAME , LOCAL_CURLOPT_CAINFO */
require_once("phpGithub.php");
require_once("phpGithubContent.php");
require_once("phpGithubUser.php");
require_once("hubHelper.php");
require_once("phpGithubServiceArray.php");

/* based on GitHub API v3 */
/* Sample usage: https://www.micro-work.net/ghac/ghaclientprofile.php */

$hub = new phpGithub();
if(gethostname()==LOCAL_HOST_NAME) { $hub->AddCurlConfig(CURLOPT_CAINFO, LOCAL_CURLOPT_CAINFO);} /* path to php/curl/cacert if needed */

$user="CSSEGISandData";
$h=new html\div($user);
start($hub,$user,$h);
echo $h->html();

function start(phpGithub $hub,string $user, \net\micro_work\php\html\div $output)
{
$response=$hub->returnUserProfile($user);
if($response->success) 
{
	$user=new phpGithubUser($response);
	$output->setGithub($user->url);
	$output->setUser($user->user);
	$output->setName($user->name);
	$output->setEmail($user->email);
	$output->setLocation($user->location);
	$output->setHomepage($user->homepage);
	$output->setDescription($user->description);
	$output->setCountRepos($user->countRepos);
#	helper::printTableFromArray($response->response);
	if($user->hasRepos == true) 
	{
		next($hub, $user->user, $output);
	}
}
	else
{
	echo $hub->getLastErrorMessage();
}
}

function next(phpGithub $hub,string $user, \net\micro_work\php\html\div $output)
{
$response=$hub->returnRepositories($user);
if($response->success) 
{
	#helper::printTableFromJson($response->response);
	foreach($response->response as $key) {
		$output->appendRepository($key);
	}
}
	else
{
	echo $hub->getLastErrorMessage();
}
}

}

namespace net\micro_work\php\html {

/**
 * Short manipulator for html dom ul li
 *
 * Customized and modified extract from net\micro_work\php\html
 *
 * @category   DOM, XML
 * @package    net\micro_work\php\html
 * @author     Original Author https://www.linkedin.com/in/jungbauer
 * @version    1.0.0
 * @dependencies domDocument, domXpath
 */
class div
{
	private $doc;
	public $tpl = "<div><section id='user'><h1>{user}</h1></section><section id='profile'></section><section id='repositories'><ul></ul></section></div>";
	private $tplUser="<table>
	<tr><th>Github</th><td>{url}</td></tr>
	<tr><th>Name</th><td>{name}</td></tr>
	<tr><th>Email</th><td>{email}</td></tr>
	<tr><th>Location</th><td>{location}</td></tr>
	<tr><th>Homepage</th><td>{homepage}</td></tr>
	<tr><th>Description</th><td>{description}</td></tr>
	</table>";
	private $tplRepos="<p>The user {user} owns {count} repositories</p>";
	private $tplRepo="<li>{full_name} <a href='{html_url}' target='gh'>&#128279;</a><br/>{description}<span class='clone'>git clone {clone_url}</span></li>\n";
	private $profile = "//section[@id='profile']";
	private $repositories = "//section[@id='repositories']";
	
	public function __construct($user)
	{
		$this->tpl=str_replace("{sha}",sha1($user),$this->tpl);
		$this->tpl=str_replace("{user}",$user,$this->tpl);
		$this->tplRepos=str_replace("{user}",$user,$this->tplRepos);
		$this->doc=new \domDocument();
		$this->doc->preserveWhiteSpace=false;
		$this->doc->loadXML($this->tpl);
	}
	public function dom() { return $this->doc;}
	
	public function getProfile()
	{
		$xpath=new \domXpath($this->doc);
		$domList=$xpath->query($this->profile);
		return $domList[0];
	}

	public function getReposistories()
	{
		$xpath=new \domXpath($this->doc);
		$domList=$xpath->query($this->repositories);
		return $domList[0];
	}
	
	public function htmlRepository()
	{
		return $this->html($this->getRepository());
	}
	
	public function htmlTree()
	{
		return $this->html($this->getTree());
	}
		
	public function html()
	{
		
		return $this->doc->saveXML($this->doc->documentElement);
	}
	
	private function elem2doc($node)
	{
		$ret = new \domDocument();
		$ret->appendChild($ret->importNode($node,true));
		return $ret;
	}
	
	public function setUser($user)
	{
		$repo=str_replace("{user}",$user,$this->tplUser);
		$this->tplUser=$repo;
		$this->writeUser($repo);
	}
	
	public function setName($user)
	{
		$repo=str_replace("{name}",$user,$this->tplUser);
		$this->tplUser=$repo;
		$this->writeUser($repo);
	}

	public function setEmail($user)
	{
		$repo=str_replace("{email}",$user,$this->tplUser);
		$this->tplUser=$repo;
		$this->writeUser($repo);
	}

	public function setLocation($user)
	{
		$repo=str_replace("{location}",$user,$this->tplUser);
		$this->tplUser=$repo;
		$this->writeUser($repo);
	}

	public function setHomepage($user)
	{
		$repo=str_replace("{homepage}",$user,$this->tplUser);
		$this->tplUser=$repo;
		$this->writeUser($repo);
	}

	public function setDescription($user)
	{
		$repo=str_replace("{description}",$user,$this->tplUser);
		$this->tplUser=$repo;
		$this->writeUser($repo);
	}

	public function setGithub($user)
	{
		$repo=str_replace("{url}",$user,$this->tplUser);
		$this->tplUser=$repo;
		$this->writeUser($repo);
	}
	
	public function setCountRepos($user)
	{
		$repo=str_replace("{count}",$user,$this->tplRepos);
		$this->tplRepos=$repo;
		$this->getProfile()->appendChild($this->dom()->importNode(dom_import_simplexml(simplexml_load_string($repo)), true));
	}
	
	private function writeUser($node)
	{
		$replNode = $this->dom()->importNode(dom_import_simplexml(simplexml_load_string($node)), true);
		$parentNode = $this->getProfile();
		if($parentNode->hasChildNodes())
		{
			$parentNode->replaceChild($replNode,$parentNode->firstChild);
		}
			else
		{
			$parentNode->appendChild($replNode);
		}
	}
	
	/* $tplRepo="<li>{full_name}<br/>{description}<br/>{html_url}<br/>{clone_url}</li>";	*/
	public function appendRepository($key)
	{
		$repo=$this->tplRepo;
		$repo=str_replace("{full_name}",$key->full_name,$repo);
		$desc=$key->description;
		if(strlen($desc)>=1) { $desc=$desc."<br/>";}
		$repo=str_replace("{description}",$desc,$repo);
		$repo=str_replace("{html_url}",$key->html_url,$repo);
		$repo=str_replace("{clone_url}",$key->clone_url,$repo);
		$replNode = $this->dom()->importNode(dom_import_simplexml(simplexml_load_string($repo)), true);
		$parentNode = $this->getReposistories()->firstChild;
		$parentNode->appendChild($replNode);
	}
	
	public function setRepository($content)
	{
		$repo=str_replace("{name}",$content->getContentProperty("name"),$this->tplRepo);
		$repo=str_replace("{full_name}",$content->getContentProperty("full_name"),$repo);
		$repo=str_replace("{description}",$content->getContentProperty("description"),$repo);
		$repo=str_replace("{html_url}",$content->getContentProperty("html_url"),$repo);
		$repo=str_replace("{updated_at}",$content->getContentProperty("updated_at"),$repo);
		$replNode = $this->dom()->importNode(dom_import_simplexml(simplexml_load_string($repo)), true);
	
		$parentNode = $this->getRepository();
		if($parentNode->hasChildNodes())
		{
			$parentNode->replaceChild($replNode,$parentNode->firstChild);
		}
			else
		{
			$parentNode->appendChild($replNode);
		}
	}
	
}
} // end of namespace
?>