<?php namespace php\github;

/**
* Class definition @version 1.0.0 @last_update 2020-05-28
*
* Model class for GitHub User based on GitHub API v3 api.github.com/users
* Objects of this class are created by phpGithub->returnUserProfile
* 
* @Dependencies
*   @class php\github\phpHubResult
*   
* @public object methods
*   __construct(phpHubResult) @return object @since 1.0.0
*
* @public object properties
*/
class phpGithubUser
{
	private $content;
	public $user;
	public $email;
	public $url;
	public $bio;
	public $description;
	public $type;
	public $isAdmin;
	public $name;
	public $company;
	public $homepage;
	public $location;
	public $created_at;
	public $updated_at;
	public $hasRepos;
	public $countRepos;
	
	public function __construct(phpHubResult $hrs) 
	{
		$this->content=$hrs->response;
		$this->user=$hrs->response->login;
		$this->name=$hrs->response->name;
		$this->email=$hrs->response->email;
		$this->url=$hrs->response->html_url;
		$this->location=$hrs->response->location;
		$this->company=$hrs->response->company;
		$this->bio=$hrs->response->bio;
		$this->description=$hrs->response->bio;
		$this->type=$hrs->response->type;
		$this->isAdmin=$hrs->response->site_admin;
		$this->homepage=$hrs->response->blog;
		$this->created_at=$hrs->response->created_at;
		$this->updated_at=$hrs->response->updated_at;
		$this->hasRepos=(boolean) $hrs->response->public_repos;
		$this->countRepos=$hrs->response->public_repos;
	}	
}	
?>