<?php
$loc_class_path="..\classes";
set_include_path(get_include_path() . PATH_SEPARATOR . $loc_class_path);
include("phpGithub.php");
$hub = new php\github\phpGithub();
echo $hub->getHubhost();
$hub->AddCurlConfig(CURLOPT_CAINFO, "/path/to/php/curl/cacert.pem");

$response=$hub->returnRoot();
if($response->success) { 
#	echo $response->response;
#	print_r($response->info);
	echo $response->urlip ." " . $response->url ." " . $response->http_code . "<br>";
}

/* returnContent with string 1.1.2 */
$repo="openZH/covid_19";
$content="fallzahlen_kanton_total_csv";
$response=$hub->returnContent($repo,$content);

echo $response->response;

// no need to download the repository before downloading content 1.1.2


/* https://github.com/openZH/covid_19/tree/master/fallzahlen_kanton_total_csv */
#$response=$hub->returnRepository("CSSEGISandData","COVID-19");
$response=$hub->returnRepository("openZH","covid_19");
if($response->success) { 
	echo $response->urlip ." " . $response->url ." " . $response->http_code . "<br>";
#	hub\helper::printTableFromArray($response->info);
#	hub\helper::printTableFromArray($response->response);
	$repo=$response->response;
#	$response=$hub->returnRootContent($repo);
	$response=$hub->returnContent($repo, "fallzahlen_kanton_total_csv");
	if($response->success) { 
		echo $response->urlip ." " . $response->url ." " . $response->http_code . "<br>";
		$contents=$response->response;
		echo $hub->hasContentsFolder()."<hr>";
#		hub\helper::printTableFromJson($contents);
		foreach($hub->getContentsIterator($contents) as $entry)
		{
#			echo $entry->type ." ". $entry->name ."<br>";
		}
		$files=new php\github\phpGithubContent($contents);
		foreach($files->getIterator() as $entry)
		{
#			echo $entry->type ." ". $entry->name ." " . $entry->path . "<br>";
		}
		echo $files->hasFilenameLike("ZH");
		echo "<br>".$files->cntFilenameLike("ZH");
		echo $files->getPathnameLike("ZH");
	}
}

$response=$hub->returnContent($repo, $files->getPathnameLike("ZH"));
if($response->success) { 
	echo $response->urlip ." " . $response->url ." " . $response->http_code . "<br>";
#	echo $response;
#	hub\helper::printTableFromArray($response->response);
	$files=new php\github\phpGithubContent($response->response);
	echo $files->isArray."<br>";
	echo $files->isObject."<br>";
	echo $files->getEncodedContent();
	echo $files->getContentProperty("download_url");
}
	
	
echo $hub->getLastErrorMessage();

?>