<?php
namespace php\github {
use php\github as hub;
use net\micro_work\php\html as html;
require_once("local.inc");
require_once("phpGithub.php");
require_once("phpGithubContent.php");
require_once("hubHelper.php");
require_once("phpGithubServiceArray.php");

/* based on GitHub API v3 */

$hub = new phpGithub();
if(gethostname()=="$LOCAL_HOST") { $hub->AddCurlConfig(CURLOPT_CAINFO, LOCAL_CURLOPT_CAINFO);} /* path to php/curl/cacert if needed */

#$owner="CSSEGISandData";
#$repository="COVID-19";
$h=new html\div($owner."/".$repository);
$ignore=array("gitignore","archive","temp",".","..","import","test","BB"); /* no lookups if a folder contains these strings */
$limit=4; // max 5 calls to github server / not to spam them with requests

start($hub,$owner,$repository,$h);
echo $h->html();

function start(phpGithub $hub,string $owner,string $repository, \net\micro_work\php\html\div $output)
{
$response=$hub->returnRepository($owner,$repository);
if($response->success) 
{
	$path=$hub->getRepository()->full_name;
	$content=new phpGithubContent($response->response);
	if($content->isRepo)
		{
			$output->setRepository($content);
			next($hub,$hub->returnRootContent($hub->getRepository()),$output);
	}
}
else
{
	echo $hub->getLastErrorMessage();
}
}

function next(phpGithub $hub,phpHubResult $response,\net\micro_work\php\html\div $output)
{
global $counter;
global $limit;
$followup=array();	
if($response->success) 
{
	echo $response->urlip ." " . $response->url ." " . $response->http_code . "<br>";
#	hub\helper::printTableFromJson($response->response);
	$content=new phpGithubContent($response->response);
	foreach($content->getIterator() as $entry)
	{
		$dir=$entry->path;
		if(dirname($entry->path) == ".") 
		{
			$dir=$hub->getRepository()->full_name;
		}
			else
		{
			$dir=$hub->getRepository()->full_name . "/" . dirname($entry->path);
		}
		if($entry->type == "file")
		{
			$output->treeLeaf($entry,$dir);
		}
			else 
		{
			$output->treeBranch($entry,$dir);
			if(notIgnore($entry->name)==true)
			{
				array_push($followup,$entry->path);
			}
		}

	}
	/* follow-up processing */


	
	if(count($followup) >=1) 
	{
		foreach($followup as $path)
		{
			$counter++;
			if($counter > $limit) { return;}	
			next($hub,$hub->returnContent($hub->getRepository(),$path),$output);
		}
	}
} 
	else 
{
	echo "Request failed<br>";
	echo $hub->getLastErrorMessage();
}
	
}


/**
  * checks if a folder name shall be ignored during the tree walk
  *
  * You may not want to walk through folders like Archive or Temp.
  * The folder name will get displayed, just the walk through will not take place
  * If value is contained in array $ignore then ignore that folder
  * 
  * @global $ignore
  * @param string $value @type folder
    *
  * @return boolean @true do not ignore the value @false ignore the value
  */
function notIgnore($value)
{
	global $ignore;
	foreach($ignore as $toignore)
	{
		if(strpos($value,$toignore) !== false) { return false;}
	}
	return true;
}

}

namespace net\micro_work\php\html {

/**
 * Short manipulator for html dom ul li
 *
 * Customized and modified extract from net\micro_work\php\html
 *
 * @category   DOM, XML
 * @package    net\micro_work\php\html
 * @author     Original Author https://www.linkedin.com/in/jungbauer
 * @version    1.0.0
 * @dependencies domDocument, domXpath
 */
class div
{
	private $doc;
	public $tpl = "<div><section id='repository'>Hallo</section><section id='tree'><ul id='{sha}'> </ul></section></div>";
	private $tplRepo="<div><b>Repository {full_name}</b><br/><a href='{html_url}' target='github'>{name} {description}</a><br/><b>Last update:</b> {updated_at}</div>";
	private $tplLeaf="<li>{name} {size} {path} <a href='{html_url}' target='leaf'>{html_url}</a></li>\n";
	private $tplBranch="<li>{name} {size} {path} <a href='{html_url}' target='leaf'>{html_url}</a>\n<ul id='{sha}'> </ul></li>\n";
	private $repository = "//section[@id='repository']";
	private $tree = "//section[@id='tree']";
	private $branch = "//ul[@id='{sha}']";
	public function __construct($dir)
	{
		$this->tpl=str_replace("{sha}",sha1($dir),$this->tpl);
		$this->doc=new \domDocument();
		$this->doc->preserveWhiteSpace=false;
		$this->doc->loadXML($this->tpl);
		$this->setRootBranch($dir);
	}
	public function dom() { return $this->doc;}
	
	public function getRepository()
	{
		$xpath=new \domXpath($this->doc);
		$domList=$xpath->query($this->repository);
		return $domList[0];
	}
	
	public function getTree()
	{
		$xpath=new \domXpath($this->doc);
		$domList=$xpath->query($this->tree);
		return $domList[0];
	}
	
	public function getBranch($id)
	{
#		$xpath=new \domXpath($this->elem2doc($this->getTree()));
		$xpath=new \domXpath($this->doc);
		$tplQuery=$this->branch;
		$query=str_replace("{sha}",$id,$tplQuery);
		$domList=$xpath->query($query,$this->getTree());
		return $domList[0];
	}
		
	public function htmlRepository()
	{
		return $this->html($this->getRepository());
	}
	
	public function htmlTree()
	{
		return $this->html($this->getTree());
	}
		
	public function html()
	{
		
		return $this->doc->saveXML($this->doc->documentElement);
	}
	
	private function elem2doc($node)
	{
		$ret = new \domDocument();
		$ret->appendChild($ret->importNode($node,true));
		return $ret;
	}
	
	public function setRepository($content)
	{
		$repo=str_replace("{name}",$content->getContentProperty("name"),$this->tplRepo);
		$repo=str_replace("{full_name}",$content->getContentProperty("full_name"),$repo);
		$repo=str_replace("{description}",$content->getContentProperty("description"),$repo);
		$repo=str_replace("{html_url}",$content->getContentProperty("html_url"),$repo);
		$repo=str_replace("{updated_at}",$content->getContentProperty("updated_at"),$repo);
		$replNode = $this->dom()->importNode(dom_import_simplexml(simplexml_load_string($repo)), true);
	
		$parentNode = $this->getRepository();
		if($parentNode->hasChildNodes())
		{
			$parentNode->replaceChild($replNode,$parentNode->firstChild);
		}
			else
		{
			$parentNode->appendChild($replNode);
		}
	}
	
	public function treeLeaf(\stdClass $entry,string $dir)
	{
		$li=str_replace("{name}",$entry->name,$this->tplLeaf);
		$li=str_replace("{path}",$entry->path,$li);
		$li=str_replace("{size}",$entry->size,$li);
		$li=str_replace("{html_url}",$entry->html_url,$li);
		$appNode = $this->dom()->importNode(dom_import_simplexml(simplexml_load_string($li)), true);
		$this->getBranch(sha1($dir))->appendChild($appNode);
	}

	
	public function treeBranch(\stdClass $entry,string $dir)
	{
		$ul=str_replace("{name}",$entry->name,$this->tplBranch);
		$ul=str_replace("{path}",$entry->path,$ul);
		$ul=str_replace("{size}",$entry->size,$ul);
		$ul=str_replace("{html_url}",$entry->html_url,$ul);
		$path = $dir . "/" . $entry->name;
		$ul=str_replace("{sha}",sha1($path),$ul);
		$appNode = $this->dom()->importNode(dom_import_simplexml(simplexml_load_string($ul)), true);
		$this->getBranch(sha1($dir))->appendChild($appNode);	}
	
	private function setRootBranch(string $dir)
	{
		$first="<li>$dir</li>";
		$appNode = $this->dom()->importNode(dom_import_simplexml(simplexml_load_string($first)), true);
		$this->getBranch(sha1($dir))->appendChild($appNode);
	}	
}
}
?>