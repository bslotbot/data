<?php
require_once("local.inc");
if(count($_POST)==1 && count($_GET)==0) 
{
	processPost();
}
if(count($_POST)==0 && count($_GET)==2) 
{
	processGitHub();
}
if(count($_POST)==0 && count($_GET)==0)
{	
	displayInputForm();
}

function displayInputForm()
{
	htmlHeader();
	htmlBodyHeader();
	htmlBodyMain();
	htmlBodyFooter();
}

function processPost()
{
	require_once("phpGithub.php");
	include("authenticate_oauth.inc"); /* client_id client_secret*/
	$hub = new php\github\phpGithub();
	if(gethostname()==LOCAL_HOST_NAME) { $hub->AddCurlConfig(CURLOPT_CAINFO, LOCAL_CURLOPT_CAINFO);} /* path to php/curl/cacert if needed */
	$scope="user";
	$github_callback="https://www.micro-work.net/ghac/ghacadduser2repo.php/";
	$hub->AddCurlConfig(CURLOPT_REFERER, "https://www.micro-work.net/ghac/ghacadduser2repo.php");
	$hub->requestAccessToken($client_id,$scope,$github_callback);
}

function processGitHub()
{
	require_once("phpGithub.php");
	require_once("phpGithubUser.php");
	include("authenticate_oauth.inc"); /* client_id client_secret*/
	$hub = new php\github\phpGithub();
	if(gethostname()==LOCAL_HOST_NAME) { $hub->AddCurlConfig(CURLOPT_CAINFO, LOCAL_CURLOPT_CAINFO);} /* path to php/curl/cacert if needed */
	$github_callback="https://www.micro-work.net/ghac/ghacadduser2repo.php/";

	$response=$hub->convertCodeToToken($client_id,$client_secret,$_GET["code"],$_GET["state"],$github_callback);
	if($response->err=="401") { $hub->requestAccessToken($client_id,$scope,$github_callback);}
	if($response->failed) { echo "failed";echo $response;}
	if($response->success) { 
		if(strpos($response->info["content_type"],"application/x-www-form-urlencoded") !== false)
		{
			parse_str($response->response,$oauth);
			$token=$oauth["access_token"];
			$Authorization="Authorization: token $token";
			$hub->AddCurlConfig(CURLOPT_HTTPGET, true);
			$hub->AddCurlHeader(CURLOPT_HTTPHEADER, array($Authorization,"Accept: application/vnd.github.machine-man-preview+json"));
			$response=$hub->returnCurrentUser();
			if($response->success)
			{
				$user = new php\github\phpGithubUser($response);
				inviteToRepository($user,$hub);
			} else {
				echo "GitHub user rejected authorzation. Or something else happened<br>";
			}
		} else {
			echo "Unknown Error. Perhaps GitHub v3 experienced a change<br>";
		}			
	}		
}

function inviteToRepository($user,$hub)
{
	htmlHeader();
	htmlBodyHeader();
	echo "<main>";
	echo "Tank you " . $user->user . "<br>";
	echo "You have just invited yourself to join GitHub repository <em><b>matjung/phpclasses_friends</b></em><br>";
	echo "<hr>";
	echo "<h1>Data Protection Policy</h1>";
	echo "<p>No, we neither stored your name as cookie, nor in localstorage or at the server</p>";
	echo "<p>If at all GitHub keeps record about your Signup</p>";
	echo "<p>Please check your emails. GitHub just sent you one. You have to confirm your wish to join the repository</p>";
	echo "<p>The self-invitation expires in about 7 days</p>";
	
$hub->AddCurlHeader(CURLOPT_HTTPHEADER, array("Authorization: token $your_token","Accept: application/vnd.github.machine-man-preview+json"));
$response=$hub->putRepositoryCollaborator("matjung","phpclasses_friends",$user->user);
if($response->success)
{
	printRepository($response->response);
	printCollaborator($response->response);
	printInvitedOn($response->response);
	echo "</main>";
}
htmlBodyFooter();
}

function printRepository($repo) { ?>
<section id="repository">
<h1>Repository</h1>
<span class="key">Name</span><span class="value"><?= $repo->repository->name ?></span><br>
<span class="key">Full Name</span><span class="value"><?= $repo->repository->full_name ?></span><br>
<span class="key">Description</span><span class="value"><?= $repo->repository->description ?></span><br>
<span class="key">GitHub url</span><span class="value"><?= $repo->repository->html_url ?></span><br>
</section>	
<?php }

function printCollaborator($coll) {?>
<section id="collaborator">
<h1>Collaborator</h1>
<span class="key">Type</span><span class="value"><?= $coll->invitee->type ?></span><br>
<span class="key">User</span><span class="value"><?= $coll->invitee->login ?></span><br>
</section>	
<?php }

function printInvitedOn($on) {?>
<section id="collaborator">
<h1>Invitation</h1>
<span class="key">Date</span><span class="value"><?= $on->created_at ?></span><br>
</section>	
<?php }

function htmlHeader() { ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="author" content="https://www.linkedin.com/in/jungbauer" />
<meta name="keywords" content="GitHub API v3 Consumer,GitHub API v3 Client" />
<meta name="description" content="Add user to GitHub Repository" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ghac - add user 2 repo</title>
<base href="https://www.micro-work.net/ghac/" />
<meta property="og:title" content="ghac - add user to repository" />
<meta property="og:description" content="Add GitHub User to GitHub Repository" />
<meta property="og:url" content="https://www.micro-work.net/ghac/ghacadduser2repo.php" />
<meta property="og:updated_time" content="<?php $ft=filemtime("ghacadduser2repo.php");echo date("Y-m-d",$ft);?>" />
<meta property="og:site_name" content="micro-work/ghac" />
<meta property="og:locale" content="EN" />
<meta property="og:image" content="https://www.micro-work.net/img/ghac.png" />
<meta property="og:type" content="website" /> 
<meta property="fb:admins" content="mat.jung.7"/>
<link href="ghacadduser2repo.css?v=1" rel="stylesheet" type="text/css">
<style>
body {
  margin: 2vh;
  display: grid;
  grid-template-rows: auto 1fr auto;
  grid-template-columns: 100%;
  height: 96vh;
}
</style>
<!script src="https://www.jsclasses.org/browse/download/1/file/19754/name/sub-dev.js?id=newsletter&s=ghaclientprofile.php&t=Thank You&e=srgmat.srgjung%2Bgithub@gmail.com" defer></script>
<script src="https://micro-work.net/subjs/sub-dev.js?id=newsletter&s=ghacadduser2repo.php&t=Thank You&e=srgmat.srgjung%2Bgithub@gmail.com" defer></script>
<script>
function hide(id) {var obj=document.getElementById(id);if(obj !=null) { obj.style.display='none';}}
function store(id) {hide(id);localStorage.setItem("mwnetghac_adduser2repo",JSON.stringify({hide:id}));}
window.onload = (event) => {
var x=localStorage.getItem("mwnetghac_adduser2repo");
if(x!=null) { x=JSON.parse(x); hide(x.hide);} };
</script>
</head>
<?php }; // end of htmlHeader

function htmlBodyHeader() { ?>
<body>
<header>
<div class="hideable" id="httpheader">
<h2>This web page does not works with Cookies but with Local Storage. <span onclick="hide('httpheader');" style="cursor:pointer;">[ X ]</span></h2>
<h3>Your browser already sent some data to this web server.</h3>
<p>This data gets logged by the Webhoster and I might use the logs to do my own statistics about you.<br>
If you click the [ X ] to the right of Local Storage - you will see this <em>section</em> whenever you come here.<br>
If you click on <span onclick="store('httpheader');" style="cursor:pointer;">&#9989;</a> I store in Local Storage that you do not want to see this section for a while</p>
<section><?php require_once("../basis/printheader.php");?></section>
</div>
<h1>Welcome to ghacadduser2repo.php</h1>
<p>At the majority of GitHub repositories you have Clone and Fork permissions.</p>
</header>
<?php }; // end of htmlBodyHeader

function htmlBodyMain() { ?>
<main>	
<p>Would you like to join the GitHub repository <em><b>matjung/phpclasses_friends</b></em> as collaborative member with write/push permissions?</p>
If yes, please login with your GitHub Account.</p>
<div id="form-wrapper">
 <form action="ghacadduser2repo.php" method="POST">
  <fieldset>
    <legend>GitHub Login</legend>
	<button type="submit" name="authorize" value="me" style="font-size:larger;">Sign in with GitHub
	<img src="../basis/GitHub-Mark-64px.png" alt="Sign in with GitHub" height=32 width=32" style="vertical-align:middle"/>
	</button>
  </fieldset>
</form> 
</div>
</main>
<?php }; // end of htmlBodyMain 

function htmlBodyFooter() { ?>
<footer>
<div id="author">
<h2>Author</h2>
<address>
<a href="https://github.com/matjung" rel="author external nofollow noreferrer" target="author" style="background-color:white;">
<img src="../basis/GitHub-Mark-64px.png" alt="github icon; link to authors github profile" height=64 width=64" style="vertical-align:middle" />
You can visit me at github</a>
</address>
The author of this web page is neither affiliated with GitHub nor with the Repository Owners.<br>
All stuff is provided as is.
</div>
<div id="related_pages">
<h2>Related Pages</h2>
<p><nav>
<a href="ghaclienttree.php">Get repository tree</a><br>
<a href="ghaclientprofile.php">Get repos per user</a>
</nav></p>
</div>
<div id="contact_form">
<h2>Contact form</h2>
<p>Suggestions for improvements?<br>
<a href="https://airtable.com/shrGut6jCsgydY63u" target="airtable" class="logo-airtable"><img src="img/airtable.png" class="logo-airtable"/> Airtable form</a>
</p>
</div>
<div id="subscription">
<h2>Newsletter</h2>
<p>Your email please<br>
<input id="newsletter" type="email" size="32" placeholder="youremail@domain.com" />
<button type="OK">OK</button><br>
(max 12 times per year)
</p>
</div>
</footer>
</body>
</html>
<?php }; // end of htmlBodyFooter ?>